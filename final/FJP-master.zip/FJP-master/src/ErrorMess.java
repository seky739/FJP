public class ErrorMess {
    public static void shout(String errorMessage){
        System.err.println(errorMessage);
        System.exit(0);
    }
}
