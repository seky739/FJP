package generator;

public interface IGenerable {

    void generateCode();
}
