package types;

import types.enums.StatementType;

public class Statement extends Identifier {
    public StatementType type;
}
