package types;

public class Program extends Identifier {
    public Block block;

    public Program(Block block){
        this.block = block;
    }
}
