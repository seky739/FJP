package types.enums;

public enum FactorType {
    BOOLEAN, NUMBER, VARIABLE, EXPRESSION, CALL
}
