package types;

import java.util.List;

public class Case  {
    public int value;
    public List<Statement> statements;

}
