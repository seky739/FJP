package types;

import java.util.List;

public class Block {
    public List<VariableDef> variableDefs;
    public List<Method> methods;
}
