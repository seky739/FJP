package types;

public class Identifier {
    public String name;

}
