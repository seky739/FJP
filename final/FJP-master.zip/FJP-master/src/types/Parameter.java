package types;

public class Parameter extends VariableDef {

}
